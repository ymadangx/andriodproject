package com.example.new2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class Main8Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);

        ImageView imageView1 = findViewById(R.id.imageView);
        ImageView imageView2 = findViewById(R.id.imageView4);
        ImageView imageView3 = findViewById(R.id.imageView5);

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main8Activity.this, "Clicked ImageView 1", Toast.LENGTH_SHORT).show();
                // 启动 Main3Activity
                startActivity(new Intent(Main8Activity.this, Main3Activity.class));
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main8Activity.this, "Clicked ImageView 2", Toast.LENGTH_SHORT).show();
                // 启动 Main4Activity
                startActivity(new Intent(Main8Activity.this, Main4Activity.class));
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main8Activity.this, "Clicked ImageView 3", Toast.LENGTH_SHORT).show();
                // 启动 Main5Activity
                startActivity(new Intent(Main8Activity.this, Main5Activity.class));
            }
        });
    }
}
