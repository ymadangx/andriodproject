package com.example.new2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class Main5Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        // Move the following lines inside the onCreate method
        ImageView imageView1 = findViewById(R.id.imageView);
        ImageView imageView2 = findViewById(R.id.imageView4);
        ImageView imageView3 = findViewById(R.id.imageView5);

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main5Activity.this, "Clicked ImageView 1", Toast.LENGTH_SHORT).show();
                // Start Main3Activity
                startActivity(new Intent(Main5Activity.this, Main3Activity.class));
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main5Activity.this, "Clicked ImageView 2", Toast.LENGTH_SHORT).show();
                // Start Main4Activity
                startActivity(new Intent(Main5Activity.this, Main4Activity.class));
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main5Activity.this, "Clicked ImageView 3", Toast.LENGTH_SHORT).show();
                // Start Main5Activity
                startActivity(new Intent(Main5Activity.this, Main5Activity.class));
            }
        });

        Button logoutButton = findViewById(R.id.button2);
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLogoutConfirmationDialog();
            }
        });
    }

    private void showLogoutConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("退出系统");
        builder.setMessage("确定退出吗？");

        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User clicked "确定," navigate to MainActivity
                startActivity(new Intent(Main5Activity.this, MainActivity.class));
                // Finish the current activity (Main5Activity) to prevent going back to it
                finish();
            }
        });

        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // User clicked "取消," do nothing or handle as needed
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
