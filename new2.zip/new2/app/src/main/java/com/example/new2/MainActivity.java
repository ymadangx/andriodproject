package com.example.new2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private TextView textViewRegister;
    private ImageView  img1,img2,img3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewRegister = findViewById(R.id.textViewRegister);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                // 示例：简单的用户名密码验证
                if (AccountManager.authenticate(username, password)) {
                    showToast("登录成功");
                    startActivity(new Intent(MainActivity.this, Main3Activity.class));
                } else {
                    showToast("登录失败，请检查用户名和密码");
                }
            }
        });

        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Main2Activity.class));
            }
        });
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 打开第一个网址
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://weibo.com/newlogin?tabtype=weibo&gid=102803&openLoginLayer=0&url=https%3A%2F%2Fwww.weibo.com%2F")));
            }
        });

        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 打开第二个网址
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://weixin.qq.com/")));
            }
        });

        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 打开第三个网址
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://xui.ptlogin2.qq.com/cgi-bin/xlogin?pt_disable_pwd=1&pt_no_auth=1&appid=809041606&daid=338&s_url=https%3A%2F%2Fti.qq.com%2Fqqlevel%2Findex%3F")));
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void goToRegister(View view) {
        startActivity(new Intent(MainActivity.this,Main2Activity.class));
    }
}
