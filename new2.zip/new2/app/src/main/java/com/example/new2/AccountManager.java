package com.example.new2;
// AccountManager.java
import java.util.ArrayList;
import java.util.List;

class AccountManager {

    private static List<Account> accountList = new ArrayList<>();

    // 初始化一些示例账户
    static {
        accountList.add(new Account("admin", "123"));
        accountList.add(new Account("gaoke", "123"));
    }

    // 验证用户登录
    public static boolean authenticate(String username, String password) {
        for (Account account : accountList) {
            if (account.getUsername().equals(username) && account.getPassword().equals(password)) {
                return true; // 匹配成功，登录成功
            }
        }
        return false; // 匹配失败，登录失败
    }

    // 注册新账户
    public static boolean register(String username, String password) {
        // 检查是否已存在相同用户名的账户
        for (Account account : accountList) {
            if (account.getUsername().equals(username)) {
                return false; // 用户名已存在，注册失败
            }
        }

        // 注册新账户
        accountList.add(new Account(username, password));
        return true; // 注册成功
    }

    private static class Account {
        private String username;
        private String password;

        public Account(String username, String password) {
            this.username = username;
            this.password = password;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }
    }
}
