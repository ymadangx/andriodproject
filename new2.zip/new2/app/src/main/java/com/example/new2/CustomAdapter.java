package com.example.new2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

// CustomAdapter.java
public class CustomAdapter extends ArrayAdapter<String> {

    private final Context context;
    private final String[] data;
    private final int[] imageResources;

    public CustomAdapter(Context context, String[] data, int[] imageResources) {
        super(context, R.layout.list_item, data);
        this.context = context;
        this.data = data;
        this.imageResources = imageResources;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.list_item, parent, false);

        TextView textView = rowView.findViewById(R.id.listItemTextView);
        ImageView imageView = rowView.findViewById(R.id.listItemImageView);
        TextView textView7 = rowView.findViewById(R.id.textView7);

        textView.setText(data[position]);

        // 设置ImageView的图片，这里使用了一个默认的图片 xinw
        imageView.setImageResource(imageResources[position]);
        textView7.setText("今日阅读120.8万 |@人民日报");
        return rowView;
    }
}
