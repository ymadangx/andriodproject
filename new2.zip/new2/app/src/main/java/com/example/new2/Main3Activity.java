package com.example.new2;
// Main3Activity.java
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.appcompat.app.AppCompatActivity;

public class Main3Activity extends AppCompatActivity {

    private ViewFlipper viewFlipper;
    private int[] images = {R.drawable.lun, R.drawable.lun1, R.drawable.lu};
    private int flipInterval = 3000;
    private Handler handler;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        viewFlipper = findViewById(R.id.viewFlipper);

        for (int image : images) {
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(image);
            viewFlipper.addView(imageView);
        }

        viewFlipper.setAutoStart(true);
        viewFlipper.setFlipInterval(flipInterval);

        viewFlipper.setInAnimation(this, android.R.anim.slide_in_left);
        viewFlipper.setOutAnimation(this, android.R.anim.slide_out_right);

        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                viewFlipper.showNext();
                handler.postDelayed(this, flipInterval);
            }
        }, flipInterval);

        listView = findViewById(R.id.listView);

        // 示例数据，你可以替换为你的实际数据
        final String[] data = {"#习近平总书发言：打好“收官战”决战“全年红”#",
                "#董宇辉孟羽童能撼动老板吗#",
                "#甘肃积石山6.2级#地震救援泪目瞬间#",
                "#五月天回应假唱风波#",
                "#周杰伦演唱会预售被嘲吃相难看#",
                "老人防止呼吸道疾病的5个知识点",
                "五月天事件黄牛票很难维权",
        "男子未捐髓救人1个月减重13斤"};
        final int[] imageResources = {R.drawable.xinw1, R.drawable.he, R.drawable.xinw8,
                R.drawable.xinw3, R.drawable.xinw4, R.drawable.xinw5, R.drawable.xinw6, R.drawable.xinw7};

        // 使用CustomAdapter设置ListView
        CustomAdapter adapter = new CustomAdapter(this, data,imageResources);
        listView.setAdapter(adapter);

        // 设置ListView的item点击监听器
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 处理item点击事件
                Toast.makeText(Main3Activity.this, "Clicked item: " + data[position], Toast.LENGTH_SHORT).show();
                // 示例：启动一个新的Activity
                startActivity(new Intent(Main3Activity.this, Main7Activity.class));
            }
        });

        ImageView imageView1 = findViewById(R.id.imageView);
        ImageView imageView2 = findViewById(R.id.imageView4);
        ImageView imageView3 = findViewById(R.id.imageView5);

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main3Activity.this, "Clicked ImageView 1", Toast.LENGTH_SHORT).show();
                // 示例：启动 Main3Activity
                startActivity(new Intent(Main3Activity.this, Main3Activity.class));
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main3Activity.this, "Clicked ImageView 2", Toast.LENGTH_SHORT).show();
                // 示例：启动 Main4Activity
                startActivity(new Intent(Main3Activity.this, Main4Activity.class));
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main3Activity.this, "Clicked ImageView 3", Toast.LENGTH_SHORT).show();
                // 示例：启动 Main5Activity
                startActivity(new Intent(Main3Activity.this, Main5Activity.class));
            }
        });
    }
}
