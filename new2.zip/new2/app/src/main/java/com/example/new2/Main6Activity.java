package com.example.new2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main6Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        // 找到按钮的引用
        Button button = findViewById(R.id.button3);

        // 为按钮设置点击事件
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 创建Intent对象，指定要跳转的Activity
                Intent intent = new Intent(Main6Activity.this, MainActivity.class);

                // 启动MainActivity
                startActivity(intent);
            }
        });
    }
}
