package com.example.new2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Main4Activity extends AppCompatActivity {

    // Declare the list
    List<String> hotSearches;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        // Move the following lines inside the onCreate method
        ImageView imageView1 = findViewById(R.id.imageView);
        ImageView imageView2 = findViewById(R.id.imageView4);
        ImageView imageView3 = findViewById(R.id.imageView5);

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main4Activity.this, "Clicked ImageView 1", Toast.LENGTH_SHORT).show();
                // Start Main3Activity
                startActivity(new Intent(Main4Activity.this, Main3Activity.class));
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main4Activity.this, "Clicked ImageView 2", Toast.LENGTH_SHORT).show();
                // Start Main4Activity
                startActivity(new Intent(Main4Activity.this, Main4Activity.class));
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main4Activity.this, "Clicked ImageView 3", Toast.LENGTH_SHORT).show();
                // Start Main5Activity
                startActivity(new Intent(Main4Activity.this, Main5Activity.class));
            }
        });

        // Initialize the list
        hotSearches = new ArrayList<>();
        hotSearches.add("1.微博堆雪人挑战大赛                                      1000万|人民网");
        hotSearches.add("2.甘肃兰州消防救援人员在积石山县大河家村四社救出被困群众2人                                                                 900万|央视网");
        hotSearches.add("3.图书馆有人破防了                                            880万|人民网");
        hotSearches.add("4.中国旅游市场持续火爆                                760万|微博新闻");
        hotSearches.add("5.刘诗诗累到虚脱  正片一剪没                          730万|腾讯网");
        hotSearches.add("6.垫底辣孩 P图思路大公开                                680万|人名网");
        hotSearches.add("7.主播陈一发儿疑似复出再被封                        650万|人民网");
        hotSearches.add("8.国乒vs韩国队                                                   600万|人民网");
        hotSearches.add("9三三 马里奥                                                    590万|微博新闻");
        hotSearches.add("10.一念关山辟谣刘诗诗打戏一剪没                  510万|人民网");
        hotSearches.add("11.宋江居然是举芦荟胶内男的                      490万|微博新闻");
        hotSearches.add("12.王楚钦孙颖莎3比0韩国组合                         450万|东方网");
        hotSearches.add("13万柳书院，万元美甲                                  300万|微博新闻");
        hotSearches.add("14.八年了她终于红了                                     310万|今日头条");
        hotSearches.add("15.甘肃6.2级地震逆流型破裂                           210万|人民网");


        // Setup ListView
        ListView listView = findViewById(R.id.listViewHotSearch);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, hotSearches);
        listView.setAdapter(adapter);

        // Set item click listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedHotSearch = hotSearches.get(position);
                Toast.makeText(Main4Activity.this, "Selected: " + selectedHotSearch, Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Main4Activity.this, Main8Activity.class));
                // You can add more logic here if needed
            }
        });
    }
}
