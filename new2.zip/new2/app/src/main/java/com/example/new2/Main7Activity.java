package com.example.new2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

public class Main7Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        VideoView videoView = findViewById(R.id.videoView2);

        // 设置本地视频文件的路径
        String videoPath = "android.resource://" + getPackageName() + "/" + R.raw.shipin;

        // 设置视频 URI
        Uri uri = Uri.parse(videoPath);
        videoView.setVideoURI(uri);

        // 开始播放视频
        videoView.start();

        ImageView imageView1 = findViewById(R.id.imageView);
        ImageView imageView2 = findViewById(R.id.imageView4);
        ImageView imageView3 = findViewById(R.id.imageView5);

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main7Activity.this, "Clicked ImageView 1", Toast.LENGTH_SHORT).show();
                // 示例：启动 Main3Activity
                startActivity(new Intent(Main7Activity.this, Main3Activity.class));
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main7Activity.this, "Clicked ImageView 2", Toast.LENGTH_SHORT).show();
                // 示例：启动 Main4Activity
                startActivity(new Intent(Main7Activity.this, Main4Activity.class));
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Main7Activity.this, "Clicked ImageView 3", Toast.LENGTH_SHORT).show();
                // 示例：启动 Main5Activity
                startActivity(new Intent(Main7Activity.this, Main5Activity.class));
            }
        });
    }
}
